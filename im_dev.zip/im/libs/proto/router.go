package proto

type Router struct {
	ServerId int8
	RoomId   int32
	UserId   string
	UserName   string
}

