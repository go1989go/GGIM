package define

const(
	NO_AUTH = "ABCDEF"
)