package define

const(
	NO_ROOM = -1
)