package define

const(
	REDIS_PREFIX = "im_"
	REDIS_ROOM_USER_PREFIX = "im_room_user_"
	REDIS_IM_COUNT = "im_count"
	REDIS_SUB = "go_im_sub"
	REDIS_BASE_VALID_TIME = 86400

)