package define

const(
	SUCCESS_REPLY = 0
	SUCCESS_REPLY_MSG = "success"


	NETWORK_ERR = -1
	NETWORK_ERR_MSG = "网络请求出错"

	SEND_ERR = -11
	SEND_ERR_MSG = "发送失败"


)