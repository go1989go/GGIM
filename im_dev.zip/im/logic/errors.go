package main

import (
	"errors"
)

var (
	ErrConnectArgs    = errors.New("connect rpc args error")
)
