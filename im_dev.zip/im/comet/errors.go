package main

import (
	"errors"
)

var (
	// room
	ErrRoomDroped = errors.New("room droped")
)

