package main
import (
	"github.com/ethereum/go-ethereum/ethclient"
	"github.com/ethereum/go-ethereum/rpc"
)
func main() {
	rpcDial, err := rpc.Dial("http://127.0.0.1:8545")
	if err != nil {
		panic(err);
	}
	client := ethclient.NewClient(rpcDial)
	client.Close()
}
