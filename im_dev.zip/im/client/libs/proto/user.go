package proto

type AuthInfo struct {
	UserId   string `json:"id"`
	UserName string `json:"UserName"`
	ServerId string `json:"ServerId"`
}
